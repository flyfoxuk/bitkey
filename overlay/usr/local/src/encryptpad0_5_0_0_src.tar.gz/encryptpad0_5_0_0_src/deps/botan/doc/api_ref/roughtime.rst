Roughtime
===========

.. versionadded:: 2.13.0

Botan includes a Roughtime client, available in ``botan/roughtime.h``
